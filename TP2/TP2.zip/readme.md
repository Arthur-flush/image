HOW TO BUILD:
make install
OR
gcc TP2_part_2.c -o huffman

HOW TO RUN:
./huffman nomdufichier.txt